.. Senpy documentation master file, created by
   sphinx-quickstart on Tue Feb 24 08:57:32 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Senpy's documentation!
=================================

Contents:

.. toctree::
   installation
   usage
   api
   plugins
   :maxdepth: 2
